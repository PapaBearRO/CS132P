#pragma once

#include "common.h"

int line_main(int argc, char** argv);

void print_line(position_t* from, const position_t* to);
